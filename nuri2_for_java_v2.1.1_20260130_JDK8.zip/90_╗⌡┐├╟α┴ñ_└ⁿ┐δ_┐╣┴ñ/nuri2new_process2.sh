#!/bin/bash
##/bin/ksh

####################################################################################
#�⺻����
####################################################################################

#==================================#
#��������(AIX), #!/bin/bash
#==================================#
#JAVA_HOME=/usr/java8
#NURI_HOME=/irais/nuri2
#NURI2_NAMES=nuri2new.jar
#==================================#

#==================================#
#��������(HP-UX), #/bin/ksh
#==================================#
JAVA_HOME=/opt/java8
NURI_HOME=/irais/nuri2
NURI2_NAMES=nuri2new.jar
#==================================#

if [ $# == 0 ]
	then echo "Usage: nuri2new_process.sh [start | stop | list | version]"; exit;
fi

#################################################
# * �ʼ� ���� �ѱ�(euckr ����)
# [����� ����] ������ �ѱ� ���ڵ� ����(locale -a|grep ko)
# �ý��ۿ� �´� locale ���� �ʿ�(��ҹ��� �ĺ�)
#################################################
# Unix , Linux �迭 ���� ������ locale Ȯ�ι��
# System(user)/home/nuri> locale -a|grep ko
#	ko_KR
#	ko_KR.euckr
#	ko_KR.utf8
#       ......
#------------------------
# * csh�� ��� setenv ko_KR.eucKR, AIX�� ��� ko_KR.IBM-eucKR
#------------------------
# .profile ����, �ý��ۿ� �´� ����(��ҹ��� ����)
# export LANG=ko_KR.eucKR
# export LANG=ko_KR.euckr
# -----------------------------
# csh�� ��� setenv LANG ko_KR.eucKR, AIX�� ��� ko_KR.IBM-eucKR
# ����: echo $LANG
#################################################
# export LANG=ko_KR.eucKR ����
#################################################
export LANG=ko_KR.IBM-eucKR
#################################################
# HP-UX
#################################################
# export LANG=ko_KR.eucKR
#################################################



NURI_HOME_LIST=`ls -al  | grep 'nuri' | awk '{print $9}'`
case "$1" in
	[Vv]ersion)
		echo "Nuri2 Solution v2.0.0"
	;;

 [Ss]tart)
	echo "START Nuri2 Process"
	case "$2" in
		[Aa]ll)
			for nuri_list in $NURI_HOME_LIST
			do
				nuri_process=`ps -ef | grep "$nuri_list/$NURI2_NAMES" | grep -v grep | wc -l`
				if [ $nuri_process -gt 0 ]
				then
				    echo "$nuri_list Nuri2 Alive."
				else
				{
					cd $NURI_HOME/$nuri_list
					nohup $JAVA_HOME/bin/java -jar $NURI_HOME/$nuri_list/$NURI2_NAMES $NURI_HOME/$nuri_list/nuri2new.conf > /dev/null &
					echo "$nuri_list Nuri2 Process Start-up."
				}
				fi
			done
			cd $NURI_HOME/
		;;
		*)
			nuri_process=`ps -ef | grep "$2/$NURI2_NAMES" | grep -v grep | wc -l`
			if [ $nuri_process != 0 ]
			then
			    echo "$2 Nuri2 Alive."
			else
			{
				cd $NURI_HOME/$2
				nohup $JAVA_HOME/bin/java -jar $NURI_HOME/$2/$NURI2_NAMES $NURI_HOME/$2/nuri2new.conf > /dev/null &
				echo "$2 Nuri2 Process Start-up."
			}
			fi
			cd $NURI_HOME/
		;;
	esac
	;;
 [Ss]top)
	echo "STOP Nuri2 Process"
	case "$2" in
		[Aa]ll)
			for nuri_list in $NURI_HOME_LIST
			do
				nuri_process=`ps -ef | grep "$NURI_HOME/$nuri_list/$NURI2_NAMES" | grep -v grep | wc -l`
				if [ $nuri_process -gt 0 ]
				then
				{
					kill_pid=`ps -ef | grep "$NURI_HOME/$nuri_list/$NURI2_NAMES" | grep -v grep | awk '{print $2}'`
					kill $kill_pid;
				    echo "$nuri_list Nuri2 Process Stop."
				}
				fi
			done
		;;
		*)
			nuri_process=`ps -ef | grep "$2/$NURI2_NAMES" | grep -v grep | wc -l`
			if [ $nuri_process != 0 ]
			then
			{
				kill_pid=`ps -ef | grep "$2/$NURI2_NAMES" | grep -v grep | awk '{if(1 == $3) print $2}'`
				kill $kill_pid;
			    echo "$2 Nuri2 Process Stop."
			}
			fi
		;;
	esac
;;
 [Ll]ist)
	echo "PID	PPID	STIME		COMMAND"
	for nuri_name1 in $NURI2_NAMES
	do
		ps -ef | grep "$nuri_name1" | grep -v grep | grep -v awk | awk '{if(9==NF) printf "%s\t%s\t%s\t%s %s\n",$2,$3,$5,$8,$9; else printf "%s\t%s\t%s %4-s\t%s %s\n",$2,$3,$5,$6,$9,$10}' | sort
	done
;;
esac
