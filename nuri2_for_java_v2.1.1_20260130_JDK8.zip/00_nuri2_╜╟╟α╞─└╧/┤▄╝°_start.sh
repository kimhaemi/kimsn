#!/bin/bash
JAVA_HOME=/opt/java8
NURI2_HOME=/home/nuri2/
NURI2_NAMES=nuri2.jar
NURI2_CONF=nuri2.conf
cd $NURI2_HOME
nohup $JAVA_HOME/bin/java  -Xms10m -Xmx200m  -jar $NURI2_HOME/$NURI2_NAMES $NURI2_HOME/$NURI2_CONF > /dev/null &
echo Nuri Process Start-up."

